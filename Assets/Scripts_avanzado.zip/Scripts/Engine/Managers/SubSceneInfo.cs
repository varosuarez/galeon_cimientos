﻿using UnityEngine;
using System.Collections;

[System.Serializable]
public class SubSceneInfo 
{
	public string m_name;
	public bool m_active;
}
