﻿using UnityEngine;
using System.Collections;

[System.Serializable]
public class TNameObject 
{
	public string Name;
	public GameObject GameObj;
}
